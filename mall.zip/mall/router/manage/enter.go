package manage

type ManageRouterGroup struct {
	ManageGoodsCategoryRouter
	ManageAdminUserRouter
	ManageGoodsInfoRouter
	ManageCarouselRouter
	ManageIndexConfigRouter
	ManageOrderRouter
}
