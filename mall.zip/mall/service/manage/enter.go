package manage

type ManageServiceGroup struct {
	ManageAdminUserService
	ManageAdminUserTokenService
	ManageUserService
	ManageGoodsCategoryService
	ManageGoodsInfoService
	ManageCarouselService
	ManageIndexConfigService
	ManageOrderService
}
