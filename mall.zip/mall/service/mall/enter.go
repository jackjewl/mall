package mall

type MallServiceGroup struct {
	MallIndexInfoService
	MallCarouselService
	MallGoodsInfoService
	MallGoodsCategoryService
	MallUserService
	MallUserTokenService
	MallUserAddressService
	MallShopCartService
	MallOrderService
}
