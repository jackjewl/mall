package request

import (
	"main.go/model/common/request"
)

type MallOrderSearch struct {
	request.PageInfo
}
