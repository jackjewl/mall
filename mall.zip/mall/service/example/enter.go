package example

type ServiceGroup struct {
	FileUploadAndDownloadService
}
