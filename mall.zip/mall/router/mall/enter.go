package mall

type MallRouterGroup struct {
	MallCarouselIndexRouter
	MallGoodsInfoIndexRouter
	MallUserRouter
	MallGoodsCategoryIndexRouter
	MallShopCartRouter
	MallOrderRouter
}
